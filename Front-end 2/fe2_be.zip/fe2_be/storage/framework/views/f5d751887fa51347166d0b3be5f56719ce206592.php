<div class="row row-cols-1 row-cols-md-3 g-4">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="card">
      <img src="<?php echo e(asset('images/' . $product->product_photo)); ?>" class="card-img-top product-photo" alt="..." data-product-id="<?php echo e($product->id); ?>">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($product->product_name); ?></h5>
        <p class="card-text">
            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge text-bg-info"><?php echo e($category->category_name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <br>
            <?php echo e($product->product_price); ?>

        </p>
      </div>
    </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\wamp64\www\fe2_be\resources\views/components/all-products.blade.php ENDPATH**/ ?>