<x-layout>
    <div class="container">
        <x-all-products/>
    </div>
</x-layout>