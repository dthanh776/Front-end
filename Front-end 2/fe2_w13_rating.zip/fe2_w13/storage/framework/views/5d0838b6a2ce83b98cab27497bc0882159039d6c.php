<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, []); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <?php if (isset($component)) { $__componentOriginal300e66d14aa6e13f0fe4118f35693ad26c6358b7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AllProducts::class, []); ?>
<?php $component->withName('all-products'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal300e66d14aa6e13f0fe4118f35693ad26c6358b7)): ?>
<?php $component = $__componentOriginal300e66d14aa6e13f0fe4118f35693ad26c6358b7; ?>
<?php unset($__componentOriginal300e66d14aa6e13f0fe4118f35693ad26c6358b7); ?>
<?php endif; ?>
    </div>    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\fe2\resources\views/home.blade.php ENDPATH**/ ?>