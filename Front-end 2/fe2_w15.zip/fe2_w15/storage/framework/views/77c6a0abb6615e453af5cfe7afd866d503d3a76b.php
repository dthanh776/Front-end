<div class="row row-cols-1 row-cols-md-3 g-4">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="col">
    <div class="card">
      <img src="<?php echo e(asset('images/' . $product->product_photo)); ?>" class="card-img-top product-photo" alt="..." data-product-id="<?php echo e($product->id); ?>">
      <div class="card-body">
        <a href="<?php echo e(route('products.show', $product->id)); ?>">
          <h5 class="card-title"><?php echo e($product->product_name); ?></h5>
        </a>
        
        <button class="btn btn-primary btn-like" data-product-id="<?php echo e($product->id); ?>" data-url="<?php echo e(route('product.like')); ?>">Like</button>
        <span class="badge bg-secondary"><?php echo e($product->likes); ?></span>

        <p class="card-text">
        <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span class="badge bg-warning text-dark"><?php echo e($category->category_name); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($product->product_price); ?>

        </p>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\wamp64\www\fe2_w13\resources\views/components/all-products.blade.php ENDPATH**/ ?>