<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, []); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <img src="<?php echo e(asset('images/' . $product->product_photo)); ?>" class="card-img-top product-photo" alt="..." data-product-id="<?php echo e($product->id); ?>">
            </div>
            <div class="col-md-8">
                <h1><?php echo e($product->product_name); ?></h1>
                <p><?php echo e($product->product_price); ?></p>
                <p>
                    <?php echo e($product->product_description); ?>

                </p>

                <ul class="list-group" id="comments-list">
                    <?php $__currentLoopData = $product->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                    <?php echo e($comment->rating); ?> -
                    <?php echo e($comment->comment_content); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="mb-3">
                    <label for="comment_content" class="form-label">Comment</label>
                    <input type="text" class="form-control" id="comment_content" name="comment_content" aria-describedby="emailHelp">
                </div>
                <div class="mb-3">
                    <label for="rating" class="form-label">Rating</label>
                    <input type="number" class="form-control" id="rating" name="rating">
                </div>
                <button id="btn-comment" type="button" class="btn btn-primary" data-product-id="<?php echo e($product->id); ?>" data-url="<?php echo e(route('comments.store')); ?>">Send</button>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\fe2_w13\resources\views/products/show.blade.php ENDPATH**/ ?>